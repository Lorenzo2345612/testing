from django.apps import AppConfig


class TipoSolicitudesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tipo_solicitudes'
