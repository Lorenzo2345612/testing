from django.shortcuts import render, redirect, get_object_or_404
from .forms import FormTipoSolicitud
from .models import TipoSolicitud


def bienvenida(request):
    return render(request, 'bienvenida.html')


def lista_solicitudes(request):
    context = {
        'tipo_solicitudes': TipoSolicitud.objects.all()
    }
    return render(request, 'lista_tipo_solicitudes.html', context)

def agregar(request):
    if request.method == 'POST':
        form = FormTipoSolicitud(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_tipo_solicitudes')
    else:
        form = FormTipoSolicitud()
    context = {
        'form': form
    }
    return render(request, 'agregar_solicitud.html', context)


def eliminar(request, id):
    tipo_solicitud = get_object_or_404(TipoSolicitud, id=id)
    tipo_solicitud.delete()
    return redirect('lista_tipo_solicitudes')


def actualizar(request, id):
    tipo_solicitud = get_object_or_404(TipoSolicitud, id=id)
    if request.method == 'POST':
        form = FormTipoSolicitud(request.POST, instance=tipo_solicitud)
        if form.is_valid():
            form.save()
            return redirect('lista_tipo_solicitudes')
    else:
        form = FormTipoSolicitud(instance=tipo_solicitud)
    context = {
        'form': form,
        'tipo_solicitud': tipo_solicitud
    }
    return render(request, 'actualizar_solicitud.html', context)
