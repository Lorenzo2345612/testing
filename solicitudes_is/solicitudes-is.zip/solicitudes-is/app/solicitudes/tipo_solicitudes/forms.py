from django import forms
from .models import TipoSolicitud

class FormTipoSolicitud(forms.ModelForm):
    class Meta:
        model = TipoSolicitud
        fields = '__all__'
        # Mensajes de error personalizados
        error_messages = {
            'nombre': {
                'unique': "El nombre de la solicitud ya existe. Por favor, elija otro nombre.",
                'max_length': "El nombre no puede exceder los 150 caracteres.",
                'required': "El campo nombre es obligatorio.",
            },
            'descripcion': {
                'max_length': "La descripción no puede exceder los 350 caracteres.",
                'required': "El campo descripción es obligatorio.",
            },
        }