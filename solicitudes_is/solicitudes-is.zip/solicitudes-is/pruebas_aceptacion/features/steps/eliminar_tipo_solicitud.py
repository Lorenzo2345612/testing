from behave import when, then
from selenium.webdriver.common.by import By
import time


# Steps para ELIMINAR
@when(u'presiono el botón Eliminar del tipo "{nombre}"')
def step_impl(context, nombre):
    # Encontrar el botón de eliminar por ID basado en el nombre
    boton_eliminar = context.driver.find_element(By.ID, f'btn-eliminar-{nombre}')
    boton_eliminar.click()
    time.sleep(1)


@then(u'no puedo ver el tipo "{nombre}" en la lista de tipos de solicitudes.')
def step_impl(context, nombre):
    body = context.driver.find_element(By.ID, 'bodyTipoSolicitudes')
    trs = body.find_elements(By.TAG_NAME, 'tr')
    tipo_solicitud = []
    for tr in trs:
        tds = tr.find_elements(By.TAG_NAME, 'td')
        if tds:
            tipo_solicitud.append(tds[0].text)
    assert nombre not in tipo_solicitud, f"'{nombre}' todavía está en la lista: {str(tipo_solicitud)}"
    time.sleep(2)
