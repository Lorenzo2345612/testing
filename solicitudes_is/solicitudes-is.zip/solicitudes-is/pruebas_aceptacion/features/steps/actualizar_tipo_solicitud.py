from behave import when, then
from selenium.webdriver.common.by import By
import time


# Steps para ACTUALIZAR
@when(u'presiono el botón Actualizar del tipo "{nombre}"')
def step_impl(context, nombre):
    # Encontrar el botón de actualizar por ID basado en el nombre
    boton_actualizar = context.driver.find_element(By.ID, f'btn-actualizar-{nombre}')
    boton_actualizar.click()
    time.sleep(1)


@when(u'cambio el nombre a "{nuevo_nombre}"')
def step_impl(context, nuevo_nombre):
    campo_nombre = context.driver.find_element(By.NAME, 'nombre')
    campo_nombre.clear()
    campo_nombre.send_keys(nuevo_nombre)
    time.sleep(0.5)


@when(u'cambio la descripción a "{nueva_descripcion}"')
def step_impl(context, nueva_descripcion):
    campo_descripcion = context.driver.find_element(By.NAME, 'descripcion')
    campo_descripcion.clear()
    campo_descripcion.send_keys(nueva_descripcion)
    time.sleep(0.5)


@when(u'presiono el botón Actualizar en el formulario')
def step_impl(context):
    context.driver.find_element(By.ID, 'btn-actualizar-form').click()
    time.sleep(1)


@then(u'el tipo tiene la descripción "{descripcion}"')
def step_impl(context, descripcion):
    body = context.driver.find_element(By.ID, 'bodyTipoSolicitudes')
    trs = body.find_elements(By.TAG_NAME, 'tr')

    for tr in trs:
        tds = tr.find_elements(By.TAG_NAME, 'td')
        if tds and len(tds) >= 2:
            desc_actual = tds[1].text
            if desc_actual == descripcion:
                # Encontramos la descripción correcta
                time.sleep(2)
                return

    # Si llegamos aquí, no encontramos la descripción
    descripciones_encontradas = []
    for tr in trs:
        tds = tr.find_elements(By.TAG_NAME, 'td')
        if tds and len(tds) >= 2:
            descripciones_encontradas.append(tds[1].text)

    assert False, f"No se encontró la descripción '{descripcion}'. Descripciones encontradas: {descripciones_encontradas}"
